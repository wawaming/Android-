package com.example.bluetooth_demo;

/**
 * Created by Administrator on 2015/9/24 0024.
 */
public class BluetoothData {
    public String HDvalue;
    public String VDvalue;
    public String AZvalue;
    public String INCvalue;
}

